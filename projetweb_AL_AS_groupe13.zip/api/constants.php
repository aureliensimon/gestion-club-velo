<?php
  // Nom de l'utilisateur
  define('DB_USER', 'Aubane');
  // Mot de passe de l'utilisateur
  define('DB_PASSWORD', 'Aubane');
  // Nom de la base de donnée
  define('DB_NAME', 'aubane');
  // Serveur
  define('DB_SERVER', 'localhost');
?>
